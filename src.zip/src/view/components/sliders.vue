<template>
    <div id="slider_content">
        <div class="slider">
            <div class="fromQuestion">123</div>
        </div>
        <div class="slider">
            <div class="fromQuestion">123</div>
        </div>
        <div class="slider">
            <div class="fromQuestion">123</div>
        </div>
        <div class="slider">
            <div class="fromQuestion">123</div>
        </div>
    </div>
</template>

<script>
import Slider from './component/slider.vue';
export default {
    data(){

    },
    components : {
        Slider
    }
}
</script>