<template>
    <div id="introduction">
        <div id="avatar">
            <img src="./../../media/avatar/avatar.png" alt="">
        </div>
        <div id="avatar_content">
            <div id="title">
                <h1>Dr.
                    <span>何宜儒</span>
                </h1>
                <h2>
                    您好，我是何醫師，歡迎您透過本網站，了解更多眼科問題。
                </h2>
            </div>
        </div>
    </div>
</template>
<script>

export default {
    data(){
        
    }
}
</script>

