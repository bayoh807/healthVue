<template>
    <div class="slider">
        <div class="fromQuestion">123</div>
    </div>
</template>
<script>
export default {
    
}
</script>