<template>
    <div id="main">
        <img id="header" src="" alt="">
        <div id="container">   
            <router-view></router-view>    
        </div>
    </div>
</template>

<script>
    const app = {
        data(){
            return {

            };
        },

    };

    export default app;
</script>